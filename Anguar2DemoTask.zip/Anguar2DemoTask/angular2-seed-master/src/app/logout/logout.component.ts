import {Component,  OnInit} from '@angular/core';



import {ActivatedRoute,Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'logout',

  templateUrl: './logout.component.html'
})
export class LogoutComponent implements OnInit {


  constructor(  private route: ActivatedRoute,private router:Router) {




  }
  ngOnInit() {
    const swal = require('sweetalert2');
    swal('Logout Successfully')
    this.router.navigate(['/Login'])


  }






}
