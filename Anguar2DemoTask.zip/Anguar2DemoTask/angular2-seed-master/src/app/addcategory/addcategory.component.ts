import {Component, HostListener, OnInit, Directive, EventEmitter} from '@angular/core';

import { categoryregistrationService } from '../bookregistration/shared/categoryregistration.service'
import {Observable} from 'rxjs/Observable';
import {ActivatedRoute,Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'ReceipeRegistration',
  styleUrls: ['./addcategory.component.css'],
  templateUrl: './addcategory.component.html'
})
export class CategoryRegistrationComponent implements OnInit {

  registrationForm: FormGroup;
  recipies: any = [];
  constructor(private formBuilder: FormBuilder, public regService: categoryregistrationService, private route: ActivatedRoute,private router:Router) {


    this.registrationForm = new FormGroup({
      name: new FormControl('', [Validators.required]),


    });

  }
  ngOnInit() {


  }

  createBook(cat) {




    let a = {
      _id: null,
      category: cat


    }

    this.regService.createCategory(a).subscribe(
      data => {
        const swal = require('sweetalert2');
        swal('Category Added Successfully');

        this.reset()
        this.router.navigate(['/ShowAllBook']);

        //return true;
      },
      error => {

        return Observable.throw(error);
      }
    );
  }

  reset() {
    for (let name in this.registrationForm.controls) {
      this.registrationForm.controls[name].setValue('');

    }
  }





}
