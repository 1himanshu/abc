import {Component, HostListener, OnInit, Directive, EventEmitter} from '@angular/core';

@Component({
  selector: 'navlink',
  styleUrls: ['./nav.component.css'],
  templateUrl: './nav.component.html'
})
export class navLink  {

  }











