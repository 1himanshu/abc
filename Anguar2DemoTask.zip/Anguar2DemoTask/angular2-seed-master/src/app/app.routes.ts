import { Routes } from '@angular/router';





import { LoginComponent } from './login/login.component';

import { RegistrationComponent } from './bookregistration/bookregistration.component';
import { UpdateBookComponent } from './updatebook/updatebook.component';
import { ShowAllBookComponent } from './showbook/showbook.component';
import { CategoryRegistrationComponent } from './addcategory/addcategory.component';
import { navLink } from './NavLink/nav.component';
import { LogoutComponent } from './logout/logout.component';
export const rootRouterConfig: Routes = [
  { path: '', redirectTo: 'Login', pathMatch: 'full' },

  { path: 'BookRegistration', component: RegistrationComponent },
  { path: 'UpdateBook/:_id', component: UpdateBookComponent },
  { path: 'ShowAllBook', component: ShowAllBookComponent },
  { path: 'AddCategory', component: CategoryRegistrationComponent },
  { path: 'Login', component: LoginComponent },
  { path: 'nav', component: navLink },
  { path: 'logout', component: LogoutComponent }


];

