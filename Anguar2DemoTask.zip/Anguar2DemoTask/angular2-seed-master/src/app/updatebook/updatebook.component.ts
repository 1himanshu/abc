import {Component, OnInit} from '@angular/core';
import {bookregistrationService} from '.././bookregistration/shared/bookregistration.service';
import {Observable} from 'rxjs/Observable';
import {ActivatedRoute} from '@angular/router';
import { Router, Params } from '@angular/router';
import {categoryregistrationService} from '.././bookregistration/shared/categoryregistration.service';


import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
    selector: 'UpdateRecipes',
    styleUrls: ['./updatebook.component.css'],
    templateUrl: './updatebook.component.html'
})
export class UpdateBookComponent implements OnInit {
    form: FormGroup;
    bookssss: any = [];
    id: any;
    availCategory:any;

    constructor(private formBuilder: FormBuilder,public ct:categoryregistrationService,public recipe: bookregistrationService, private router: Router ,private route: ActivatedRoute) {

        this.form = new FormGroup({
          iddd: new FormControl('', [Validators.required]),
          titles: new FormControl('', [Validators.required]),
          shortdescriptions: new FormControl('', [Validators.required, ]),
          descriptions: new FormControl('', [Validators.required]),
          authors: new FormControl('', [Validators.required]),
          categorys: new FormControl('', [Validators.required]),
          dates: new FormControl('', [Validators.required]),

        });


    }

    ngOnInit()
    {

        this.route.params.subscribe((params: Params) => {
            this.id = params['_id'];

            this.getRecipes(this.id);

        });

      this.route.params.subscribe(params => {

        this.ct.getAllCAtegory().subscribe(catDetails => {

          this.availCategory = catDetails;

          /*this.recipies = Array(this.recipies); *///for the array
        });
      });
       // this.validate();


    }

    getRecipes(id) {

    this.route.params.subscribe(params => {

        this.recipe.getBook(id).subscribe(recipeDetails => {
          debugger;



            this.bookssss = recipeDetails;

            //this.form.setValue({ name: recipeDetails.name, category: recipeDetails.category, price: recipeDetails.price, details: recipeDetails.deatils});
            /*this.recipies = Array(this.recipies); *///for the array
        });
    });
    }




  updateBook(idds,titles,shortdescriptions,descriptions,authors,categorys,datess) {


        let a = {
          _id:this.id,
          idd: idds,
          title: titles,
          shortdescription: shortdescriptions,
          description: descriptions,
          author:authors,
          category:categorys,
          datess:datess
        }

        this.recipe.updateBook(a).subscribe(
            data => {
              const swal = require('sweetalert2');
              swal('Record Updated Successfully');

                var sasds = data;

                this.router.navigate(['/ShowAllBook']);
                return true;
            },
            error => {

                return Observable.throw(error);
            }
        );
    }

    navigates()
    {
        this.router.navigate(['/ShowAllBook']);
    }

}
