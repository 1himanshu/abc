import {Component, HostListener, OnInit, Directive, EventEmitter} from '@angular/core';


import {Observable} from 'rxjs/Observable';
import {ActivatedRoute,Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';


@Component({
  selector: 'app',
  styleUrls: ['./login.component.css'],
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

  registrationForm: FormGroup;
  recipies: any = [];
  constructor(private formBuilder: FormBuilder,  private route: ActivatedRoute,private router:Router) {


    this.registrationForm = new FormGroup({
      name: new FormControl('', [Validators.required]),


    });

  }
  ngOnInit() {


  }

sub(pass){

  var CryptoJS = require("crypto-js");
  var key = CryptoJS.enc.Utf8.parse('7061737323313233');
  var iv = CryptoJS.enc.Utf8.parse('7061737323313233');
  var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(pass), key,
    {
      keySize: 128 / 8,
      iv: iv,
      mode: CryptoJS.mode.CBC,
      padding: CryptoJS.pad.Pkcs7
    });
  var pwd="BtZLZnxvC5EJK9YjhNAt+ZuxA9jLX3Ts6VVPqbPsG3M=";
  if(pwd==encrypted){
    const swal = require('sweetalert2');
    swal('You Are Login Successfully');
  // localStorage.setItem('currentUser',JSON.stringify(pass) );
      this.router.navigate(['/ShowAllBook']);
    }
else {
    const swal = require('sweetalert2');
    swal('Password NOt Matched');

      //alert('password not matched');
    }

}




}
