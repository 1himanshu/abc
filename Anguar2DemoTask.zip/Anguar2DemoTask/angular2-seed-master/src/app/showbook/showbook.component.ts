import {Component, OnInit, Injectable} from '@angular/core';
import {bookregistrationService} from '.././bookregistration/shared/bookregistration.service';
import {categoryregistrationService} from '.././bookregistration/shared/categoryregistration.service';
import {Observable} from 'rxjs/Observable';
import {ActivatedRoute} from '@angular/router';
import { Router } from '@angular/router';




@Component({
    selector: 'ShowRecipes',
    styleUrls: ['./showbook.component.css'],
    templateUrl: './showbook.component.html'
})


@Injectable()
export class ShowAllBookComponent  {
    booksss: any;
  cate:any;


    constructor(public recipe: bookregistrationService,public ct:categoryregistrationService ,private route: ActivatedRoute) {
    }
  ngOnInit(){

    this.showAllBook();



      //called after the constructor and called  after the first ngOnChanges()


    //called after the constructor and called  after the first ngOnChanges()
  }


  showAllBook() {
        this.route.params.subscribe(params => {

            this.recipe.getAllBook().subscribe(bookDetails => {

                this.booksss = bookDetails;

                /*this.recipies = Array(this.recipies); *///for the array
            });
        });

    }
    deleteBook(id: string) {
      if (confirm("Are You Sure To Delete ?") == true) {
        this.recipe.deleteBook(id).subscribe(
          data => {
            const swal = require('sweetalert2');
            swal('Record Deleted Successfully');
            this.showAllBook();

            return true;
          },
          error => {


            return Observable.throw(error);
          }
        );
      } else {

      }
        //confirm("are you sure");





    }



}
