import {Component, HostListener, OnInit, Directive, EventEmitter} from '@angular/core';

import { bookregistrationService } from './shared/bookregistration.service'
import {Observable} from 'rxjs/Observable';
import {ActivatedRoute,Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import {categoryregistrationService} from '.././bookregistration/shared/categoryregistration.service';


@Component({
    selector: 'ReceipeRegistration',
    styleUrls: ['./bookregistration.component.css'],
    templateUrl: './bookregistration.component.html'
})
export class RegistrationComponent implements OnInit {

    registrationForm: FormGroup;

    cate:any;
    constructor(private formBuilder: FormBuilder,public router:Router,public catService:categoryregistrationService, public regisService: bookregistrationService, private route: ActivatedRoute) {


        this.registrationForm = new FormGroup({
          id: new FormControl('', [Validators.required]),
          title: new FormControl('', [Validators.required]),
          shortdescription: new FormControl('', [Validators.required, ]),
          description: new FormControl('', [Validators.required]),
          author: new FormControl('', [Validators.required]),
          category: new FormControl('', [Validators.required]),
          dates: new FormControl('', [Validators.required]),

        });

    }
    ngOnInit() {
      this.route.params.subscribe(params => {

        this.catService.getAllCAtegory().subscribe(catDetails => {

          this.cate = catDetails;

          /*this.recipies = Array(this.recipies); *///for the array
        });
      });


    }

  createBook(idds,titles,shortdescriptions,descriptions,authors,categorys,datess) {



        let a = {
            _id: null,
            idd: idds,
            title: titles,
            shortdescription: shortdescriptions,
            description: descriptions,
            author:authors,
            category:categorys,
            datess:datess

        }

        this.regisService.createBook(a).subscribe(
            data => {
              const swal = require('sweetalert2');
              swal('Book Added Successfully');
              this.router.navigate(['/ShowAllBook'])

             //   this.reset()
               // return true;
                    },
            error => {

                return Observable.throw(error);
            }
        );
    }

   // reset() {
     //   for (let name in this.registrationForm.controls) {
         //   this.registrationForm.controls[name].setValue('');

       // }
   // }


}
