import { Injectable } from '@angular/core';
//import { Http, URLSearchParams } from '@angular/http';
import {Http, Response, URLSearchParams, Headers, RequestOptions} from '@angular/http';

import 'rxjs/add/operator/map';

@Injectable()
export class categoryregistrationService {
  constructor(private http: Http) { }






  createCategory(us) {

    let headers = new Headers({ 'Content-Type': 'application/json' });//added food
    headers.append("Access-Control-Allow-Origin", "*");
    let options = new RequestOptions({ headers: headers });
    options.body = us;

    let url = "http://localhost:3001/Category";
    let body = us; //JSON.stringify(food);
    return this.http.post(url, body, options).map(((res: Response) => res.json()));
  }
  deleteCategory(id) {

    let headers = new Headers({ 'Content-Type': 'application/json' });
    headers.append("Access-Control-Allow-Origin", "*");
    let options = new RequestOptions({ headers: headers });
    let url = "http://localhost:3001/Category/" + id;
    return this.http.delete(url, options);
  }
  getCategory(id)
  {


    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    let body = JSON.stringify(id);
    let url = "http://localhost:3001/Category/" + id;
    return this.http.get(url).map((res: Response) => res.json());

  }
  getAllCAtegory() {

    let url = "http://localhost:3001/Category";
    let params = new URLSearchParams();
    let headers = new Headers();
    headers.append("Access-Control-Allow-Origin", "*");
    let options = new RequestOptions({ headers: headers, search: params });
    return this.http.get(url, options)
      .map(res => res.json());


  }
  updateCategory(ct) {

    let headers = new Headers({ 'Content-Type': 'application/json' });//added food
    headers.append("Access-Control-Allow-Origin", "*");
    let options = new RequestOptions({ headers: headers });
    options.body = ct;

    let url = "http://localhost:3001/Category/"+ct._id;
    let body = ct; //JSON.stringify(food);
    return this.http.put(url, body, options).map(((res: Response) => res.json()));
  }
}
