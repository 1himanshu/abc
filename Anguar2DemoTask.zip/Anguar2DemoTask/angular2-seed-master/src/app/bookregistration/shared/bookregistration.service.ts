import { Injectable } from '@angular/core';
//import { Http, URLSearchParams } from '@angular/http';
import {Http, Response, URLSearchParams, Headers, RequestOptions} from '@angular/http';

import 'rxjs/add/operator/map';

@Injectable()
export class bookregistrationService {
    constructor(private http: Http) { }






  createBook(us) {

        let headers = new Headers({ 'Content-Type': 'application/json' });//added food
        headers.append("Access-Control-Allow-Origin", "*");
        let options = new RequestOptions({ headers: headers });
        options.body = us;
        debugger;
        let url = "http://localhost:3001/userregistration";
        let body = us; //JSON.stringify(food);
        return this.http.post(url, body, options).map(((res: Response) => res.json()));
    }
    deleteBook(id) {

        let headers = new Headers({ 'Content-Type': 'application/json' });
        headers.append("Access-Control-Allow-Origin", "*");
        let options = new RequestOptions({ headers: headers });
        let url = "http://localhost:3001/userregistration/" + id;
        return this.http.delete(url, options);
    }
    getBook(id)
    {

        debugger;
        let headers = new Headers({ 'Content-Type': 'application/json' });
        let options = new RequestOptions({ headers: headers });
        let body = JSON.stringify(id);
        let url = "http://localhost:3001/userregistration/" + id;
        return this.http.get(url).map((res: Response) => res.json());

    }
     getAllBook() {

        let url = "http://localhost:3001/userregistration";
        let params = new URLSearchParams();
        let headers = new Headers();
        headers.append("Access-Control-Allow-Origin", "*");
        let options = new RequestOptions({ headers: headers, search: params });
        return this.http.get(url, options)
            .map(res => res.json());


    }
    updateBook(books) {

        let headers = new Headers({ 'Content-Type': 'application/json' });//added food
        headers.append("Access-Control-Allow-Origin", "*");
        let options = new RequestOptions({ headers: headers });
        options.body = books;
        debugger;
        let url = "http://localhost:3001/userregistration/"+books._id;
        let body = books; //JSON.stringify(food);
        return this.http.put(url, body, options).map(((res: Response) => res.json()));
    }
}
