import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router';
import { rootRouterConfig } from './app.routes';
import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';





import { LocationStrategy, HashLocationStrategy } from '@angular/common';

import { RegistrationComponent } from './bookregistration/bookregistration.component';
import { bookregistrationService } from './bookregistration/shared/bookregistration.service';
import { categoryregistrationService } from './bookregistration/shared/categoryregistration.service';
import { UpdateBookComponent } from './updatebook/updatebook.component';
import { ShowAllBookComponent } from './showbook/showbook.component';
import { CategoryRegistrationComponent } from './addcategory/addcategory.component';
import { LoginComponent } from './login/login.component';
import { navLink } from './NavLink/nav.component';
import { LogoutComponent } from './logout/logout.component';



@NgModule({
  declarations: [
    AppComponent,

    LoginComponent,
    RegistrationComponent,

    navLink,
    LogoutComponent,

    UpdateBookComponent,
    ShowAllBookComponent,
    CategoryRegistrationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule.forRoot(rootRouterConfig, { useHash: false })
  ],
  providers: [
    bookregistrationService,
    categoryregistrationService
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule {

}
