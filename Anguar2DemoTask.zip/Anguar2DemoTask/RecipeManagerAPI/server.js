var cors = require('cors');
var express = require('express'),
  app = express(),
  port = process.env.PORT || 3001,
  mongoose = require('mongoose'),
  
  Tasks = require('./api/models/userRegistrationModel'),
  Taskss = require('./api/models/addCategoryModel'),
 
  bodyParser = require('body-parser');
  
mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/recipeManagement',{ useMongoClient: true }); 

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());





var routess = require('./api/routes/userRegistrationRoute');



routess(app);
var routesss = require('./api/routes/addCategoryRoute');
routesss(app)


app.listen(port);
console.log('todo list RESTful API server started on: ' + port);
