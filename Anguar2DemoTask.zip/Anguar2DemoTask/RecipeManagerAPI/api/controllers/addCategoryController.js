﻿'use strict';
var mongoose = require('mongoose'),
    registeruserSchemass = mongoose.model('Category');

exports.list_all_category = function (req, res) {
    registeruserSchemass.find({}, function (err, user) {
        if (err)
            res.send(err);
        res.json(user);
    });
};




exports.create_a_category = function (req, res) {
    var new_user = new registeruserSchemass(req.body);
    new_user.save(function (err, user) {
        if (err)
            res.send(err);
        res.json(user);
    });
};


exports.read_a_category = function (req, res) {
    registeruserSchemass.findById(req.params.userId, function (err, user) {
        if (err)
            res.send(err);
        res.json(user);
    });
};


exports.update_a_category = function (req, res) {
    registeruserSchemass.findOneAndUpdate({ _id: req.params.userId }, req.body, { new: true }, function (err, user) {
        if (err)
            res.send(err);
        res.json(user);
    });
};


exports.delete_a_category = function (req, res) {


    registeruserSchemass.remove({
        _id: req.params.userId
    }, function (err, user) {
        if (err)
            res.send(err);
        res.json({ message: 'Category successfully deleted' });
    });
};

