﻿'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var registeruserSchemas = new Schema({
    _id: {
        type: Schema.Types.ObjectId
    },
    __v: { type: Number, select: false },
   
    category: {
        type: String,
        Required: 'Kindly enter the category of the task'
    },
   

}, { collection: 'Category' });

module.exports = mongoose.model('Category', registeruserSchemas);