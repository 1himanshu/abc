﻿'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;


var registeruserSchemas = new Schema({
    _id: {
        type: Schema.Types.ObjectId
    },
    __v: { type: Number, select: false },
    idd:{
        type: String,
        Required: 'Kindly enter the name of the task'
    },
    title:{
        type: String,
        Required: 'Kindly enter the category of the task'
    },
 shortdescription:{
        type: String,
        Required: 'Kindly enter the category of the task'
    },
 description:{
        type: String,
        Required: 'Kindly enter the category of the task'
    },
 author:{
        type: String,
        Required: 'Kindly enter the category of the task'
    },
category:{
        type: String,
        Required: 'Kindly enter the price of the task'
    },
 datess:{
        type: String,
        Required: 'Kindly enter the category of the task'
    },
    
}, { collection: 'UserRegistration' });

module.exports = mongoose.model('UserRegistration', registeruserSchemas);